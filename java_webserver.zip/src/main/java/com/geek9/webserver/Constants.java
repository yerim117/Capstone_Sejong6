package com.geek9.webserver;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Constants {
	
	public static final String LOG_START_FORMAT = "[%s_%s] %s START : %s\n";
	public static final String LOG_END_FORMAT = "[%s_%s] %s END : %s\n";
	public static final Object KEY_URL = "url";
    public static final String ORACLE = "oracle";

	public static final String SQL_IS_EXIST_USER = "isExistUser";
	public static final String SQL_INSERT_USER = "insertUser";
	public static final String SQL_IS_EXIST_ID = "isExistId";
    
    public static String getDate() {
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
		return sdf.format(d);
	}
	
}

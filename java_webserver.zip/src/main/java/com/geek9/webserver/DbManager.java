package com.geek9.webserver;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.geek9.webserver.vo.UserVO;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

public class DbManager {
	private static Integer getSeq(int seq) {
		return seq < 0 ? null : seq;
	}
	public static Map<String, Object> jsonStringToMap(String jsonString) {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			System.out.println("params: " + jsonString);
			JsonObject obj = new JsonParser().parse(jsonString).getAsJsonObject();
			for (String key : obj.keySet()) {
				map.put(key, obj.get(key).getAsString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	
	public static boolean login(String id, String password) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "isExistId", Constants.getDate(),  id));
		
		conn = DBUtil.getConnection();
		String query = "select * from CUSTOMER where id = '%s' and password = '%s'";
		query = String.format(query, id, password);
		
		Statement st = null;
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;

	}
	
	public static boolean insertCustomer(String id, String name, String password, String pnum) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "isExistId", Constants.getDate(),  id));
		
		conn = DBUtil.getConnection();

		String query = "INSERT INTO customer(seq, id, NAME, PASSWORD, pnum) VALUES(customer_seq.NEXTVAL, '%s', '%s', '%s', '%s')";
		query = String.format(query, id, name, password, pnum);

		Statement st = null;
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;

	}
	
	public static String selectCustomers(Map<String, Object> params) {
		Connection conn = null;
		Statement stmt = null;
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "params", Constants.getDate(),  params));
		
		conn = DBUtil.getConnection();

		String query = "SELECT seq, id, name, password, pnum FROM customer";
		System.out.println("params: " + params);
		if (params != null && !params.isEmpty()) {
			String where = "";
			for (String key : params.keySet()) {
				if (!where.isEmpty()) {
					where += " AND ";
				}
				String value = (String) params.get(key);
				if (key.equals("name")) {
					where += key + " LIKE '%" + value + "%'";
				} else {
					where += key + "=" + value;
				}
				
			}
			query += " WHERE " + where;
		}
		
		System.out.println("query: " + query);
		Statement st = null;
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject folderObj = new JsonObject();
				int seq = rs.getInt("seq");
				folderObj.addProperty("seq", seq);
				String id = rs.getString("id");
				if (id != null)
					folderObj.addProperty("id", id);
				String name = rs.getString("name");
				if (name != null)
					folderObj.addProperty("name", name);
				String pnum = rs.getString("pnum");
				if (pnum != null)
					folderObj.addProperty("pnum", pnum);
				array.add(folderObj);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}
	
	public static boolean updateCustomer(int customerSeq, Map<String, Object> params) throws SQLException {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "customerSeq", Constants.getDate(),  customerSeq));
		conn = DBUtil.getConnection();
		
		String query = "UPDATE CUSTOMER SET ";
		String valuesString = "";
		for (String key : params.keySet()) {
			if (!valuesString.isEmpty()) {
				valuesString += ",";
			}
			valuesString += key + "=" + params.get(key);
		}
		query += valuesString + " WHERE seq = " + customerSeq;
		System.out.println("query: " + query);
		Statement st = null;
		try {
			st = conn.createStatement();
			System.out.println("LINE #1");
			ResultSet rs = st.executeQuery(query);
			System.out.println("LINE #2 : " + rs);
			if(rs.next()) {    
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	// TODO: select user
	public static boolean updatePassword(String id, String newPassword) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "isExistId", Constants.getDate(),  id));
		
		conn = DBUtil.getConnection();
		String query = "update CUSTOMER set PASSWORD='%s' where id='%s'" ;
		query = String.format(query, newPassword, id);
		
		Statement st = null;
		try {
			st = conn.createStatement();
			int r = st.executeUpdate(query);
			System.out.println("r: " + r);
			return r == 1;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;


	}
	
	public static boolean deleteCustomer(int customerSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "customerSeq", Constants.getDate(),  customerSeq));
		
		conn = DBUtil.getConnection();

		String query = "delete from CUSTOMER where seq=%d";
		query = String.format(query, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;

	}
	
	public static final int RESERVE_PERIOD_TYPE_MONTH = 0;
	public static final int RESERVE_PERIOD_TYPE_WEEK = 1;
	public static final int RESERVE_PERIOD_WEEK_1 = 1;
	public static final int RESERVE_PERIOD_WEEK_2 = 2;
	public static final int RESERVE_PERIOD_WEEK_3 = 3;
	public static final int RESERVE_PERIOD_WEEK_4 = 4;
	public static final int RESERVE_PERIOD_DAY_SUN = 0;
	public static final int RESERVE_PERIOD_DAY_MON = 1;
	public static final int RESERVE_PERIOD_DAY_TUE = 2;
	public static final int RESERVE_PERIOD_DAY_WED = 3;
	public static final int RESERVE_PERIOD_DAY_THU = 4;
	public static final int RESERVE_PERIOD_DAY_FRI = 5;
	public static final int RESERVE_PERIOD_DAY_SAT = 6;
	public static boolean insertFolder(String title, int parentFolderSeq, String reserveTitle, int reserveWriterCustomerSeq, String reserveLocation, 
			int reservePeriodType, int reservePeriodWeek, int reservePeriodDay, String reserveStartTime, String reserveEndTime) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "reserveWriterCustomerSeq", Constants.getDate(),  reserveWriterCustomerSeq));
		
		conn = DBUtil.getConnection();
		String query = "INSERT INTO folder"
				+ "(seq, title, parent_folder_seq, reserve_title, RESERVE_WRITER_CUSTOMER_SEQ, "
				+ "RESERVE_LOCATION, RESERVE_PERIOD_TYPE, RESERVE_PERIOD_WEEK, RESERVE_PERIOD_DAY,"
				+ "RESERVE_START_TIME, RESERVE_END_TIME) " 
				+ "VALUES"
				+ "(folder_seq.NEXTVAL, '%s', %d, '%s', %d, '%s', %d, %d, %d, '%s', '%s')";
		query = String.format(query, title, getSeq(parentFolderSeq), reserveTitle, 
				getSeq(reserveWriterCustomerSeq), reserveLocation, 
				getSeq(reservePeriodType), getSeq(reservePeriodWeek), getSeq(reservePeriodDay),
				reserveStartTime, reserveEndTime);
		System.out.println("query: " + query);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;

	}
	
	public static String selectFolders(int parentFolderSeq) {
		Connection conn = null;
		Statement stmt = null;
		String retVal="";
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "parentFolderSeq", Constants.getDate(),  parentFolderSeq));
		
		conn = DBUtil.getConnection();

		String query = "SELECT seq, title, parent_folder_seq, reserve_writer_customer_seq, reserve_title, reserve_location, "
				+ "reserve_period_type, reserve_period_week, reserve_period_day, reserve_start_time, reserve_end_time" 
				+ " FROM folder";
		if (parentFolderSeq > 0) {
			query += " WHERE parent_folder_seq=" + parentFolderSeq;
		}
		Statement st = null;
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject folderObj = new JsonObject();
				int seq = rs.getInt("seq");
				folderObj.addProperty("seq", seq);
				String title = rs.getString("title");
				if (title != null)
					folderObj.addProperty("title", title);
				int parentFolderSeq_ = rs.getInt("parent_folder_seq");
				if (parentFolderSeq_ > 0)
					folderObj.addProperty("parent_folder_seq", parentFolderSeq_);
				int reserveWriterCustomerSeq = rs.getInt("reserve_writer_customer_seq");
				if (reserveWriterCustomerSeq > 0)
					folderObj.addProperty("reserve_writer_customer_seq", reserveWriterCustomerSeq);
				String reserveTitle = rs.getString("reserve_title");
				if (reserveTitle != null)
					folderObj.addProperty("reserve_title", reserveTitle);
				String reserveLocation = rs.getString("reserve_location");
				if (reserveLocation != null)
					folderObj.addProperty("reserve_location", reserveLocation);
				int reservePeriodType = rs.getInt("reserve_period_type");
				if (reservePeriodType > 0)
					folderObj.addProperty("reserve_period_type", reservePeriodType);
				int reservePeriodWeek = rs.getInt("reserve_period_week");
				if (reservePeriodWeek > 0)
					folderObj.addProperty("reserve_period_week", reservePeriodWeek);
				int reservePeriodDay = rs.getInt("reserve_period_day");
				if (reservePeriodDay > 0)
					folderObj.addProperty("reserve_period_day", reservePeriodDay);
				String reserveStartTime = rs.getString("reserve_start_time");
				if (reserveStartTime != null)
					folderObj.addProperty("reserve_start_time", reserveStartTime);
				String reserveEndTime = rs.getString("reserve_end_time");
				if (reserveEndTime != null)
					folderObj.addProperty("reserve_end_time", reserveEndTime);
				array.add(folderObj);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}
	
	public static boolean updateFolder(int folderSeq, Map<String, Object> params) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		conn = DBUtil.getConnection();
		
		String query = "UPDATE folder SET ";
		String valuesString = "";
		for (String key : params.keySet()) {
			if (!valuesString.isEmpty()) {
				valuesString += ",";
			}
			valuesString += key + "=" + params.get(key);
		}
		query += valuesString + " WHERE seq = " + folderSeq;
		Statement st = null;
		try {  
			st = conn.createStatement();
			System.out.println("query: " + query);
			ResultSet rs = st.executeQuery(query);
			System.out.println("LINE #2 : " + rs);
			if(rs.next()) {    
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	
	public static boolean deleteFolder(int folderSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();

		String query = "DELETE FROM folder WHERE seq=%d";
		query = String.format(query, folderSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;

	}
	
	public static boolean insertNote(int folderSeq, String title, String regTime, String startTime, 
			String endTime, String location, int writerCustomerSeq, String contents) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "writerCustomerSeq", Constants.getDate(),  writerCustomerSeq));
		
		conn = DBUtil.getConnection();
		String query = "INSERT INTO note"
				+ "(seq, folder_seq, title, reg_time, start_time, end_time, location, writer_customer_seq, contents) " 
				+ "VALUES"
				+ "(note_seq.NEXTVAL, %d, '%s', '%s', '%s', '%s', '%s', %d, '%s')";
		query = String.format(query, folderSeq, title, regTime, startTime, 
				endTime, location, writerCustomerSeq, contents);
		Statement st = null;

		try {
			st = conn.createStatement();
			System.out.println("query: " + query);
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	public static String selectNotes(int writercustomerseq,int folderSeq) {
		Connection conn = null;
		Statement stmt = null;
		String retVal="";
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();
		
		String query = "SELECT seq, folder_seq, title, reg_time, start_time, end_time, location, writer_customer_seq, contents"
				+ " FROM note WHERE writer_customer_seq=%d and folder_seq=%d order by seq";
		
		query = String.format(query, writercustomerseq, folderSeq);

		Statement st = null;
		
		System.out.println("query Test : "+query);
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject noteObj = new JsonObject();
				int seq = rs.getInt("seq");
				noteObj.addProperty("seq", seq);
				int folderSeq_ = rs.getInt("folder_seq");
				if (folderSeq_ > 0)
					noteObj.addProperty("folder_seq", folderSeq_);
				String title = rs.getString("title");
				if (title != null)
					noteObj.addProperty("title", title);
				String regTime = rs.getString("reg_time");
				if (regTime != null)
					noteObj.addProperty("reg_time", regTime);
				String startTime = rs.getString("start_time");
				if (startTime != null)
					noteObj.addProperty("start_time", startTime);
				String endTime = rs.getString("end_time");
				if (endTime != null)
					noteObj.addProperty("end_time", endTime);
				String location = rs.getString("location");
				if (location != null)
					noteObj.addProperty("location", location);
				int writerCustomerSeq = rs.getInt("writer_customer_seq");
				if (writerCustomerSeq > 0)
					noteObj.addProperty("writer_customer_seq", writerCustomerSeq);
				String contents = rs.getString("contents");
				if (contents != null)
					noteObj.addProperty("contents", contents);
				array.add(noteObj);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}

	public static String selectNotes2(int noteseq) {
		Connection conn = null;
		Statement stmt = null;
		String retVal="";
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteseq����", Constants.getDate(),  noteseq));
		
		conn = DBUtil.getConnection();
		
//		String query = "SELECT seq, folder_seq, title, reg_time, start_time, end_time, location, writer_customer_seq, contents"
//	            + " FROM note WHERE (writer_customer_seq=%d and folder_seq=%d) or (note_seq in (%s)) order by seq";
		
		String query = "SELECT seq, folder_seq, title, reg_time, start_time, end_time, location, writer_customer_seq, contents"
	            + " FROM note WHERE seq=%d order by seq";
		
//		query = String.format(query, writercustomerseq, folderSeq);
		query = String.format(query, noteseq);

		Statement st = null;
		
		System.out.println("query Test : "+query);
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject noteObj = new JsonObject();
				int seq = rs.getInt("seq");
				noteObj.addProperty("seq", seq);
				int folderSeq_ = rs.getInt("folder_seq");
				if (folderSeq_ > 0)
					noteObj.addProperty("folder_seq", folderSeq_);
				String title = rs.getString("title");
				if (title != null)
					noteObj.addProperty("title", title);
				String regTime = rs.getString("reg_time");
				if (regTime != null)
					noteObj.addProperty("reg_time", regTime);
				String startTime = rs.getString("start_time");
				if (startTime != null)
					noteObj.addProperty("start_time", startTime);
				String endTime = rs.getString("end_time");
				if (endTime != null)
					noteObj.addProperty("end_time", endTime);
				String location = rs.getString("location");
				if (location != null)
					noteObj.addProperty("location", location);
				int writerCustomerSeq = rs.getInt("writer_customer_seq");
				if (writerCustomerSeq > 0)
					noteObj.addProperty("writer_customer_seq", writerCustomerSeq);
				String contents = rs.getString("contents");
				if (contents != null)
					noteObj.addProperty("contents", contents);
				array.add(noteObj);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}
	
	public static boolean updateNote(int noteSeq, Map<String, Object> params) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteSeq", Constants.getDate(),  noteSeq));
		conn = DBUtil.getConnection();
		
		String query = "UPDATE note SET ";
		String valuesString = "";
		for (String key : params.keySet()) {
			if (!valuesString.isEmpty()) {
				valuesString += ",";
			}
			valuesString += key + "=" + params.get(key);
		}
		query += valuesString + " WHERE seq = " + noteSeq;
		Statement st = null;
		try {  
			st = conn.createStatement();
			System.out.println("query: " + query);
			ResultSet rs = st.executeQuery(query);
			System.out.println("LINE #2 : " + rs);
			if(rs.next()) {    
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}

	public static boolean deleteNote(int noteSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteSeq", Constants.getDate(),  noteSeq));
		
		conn = DBUtil.getConnection();
		String query = "DELETE FROM note WHERE seq=" + noteSeq;
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	
	public static final int AUTH_WRITHE_DENIED = 0;
	public static final int AUTH_WRITHE_GRANTED = 1;
	public static boolean insertNoteCustomerMapping(int noteSeq, int customerSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteSeq", Constants.getDate(),  noteSeq));
		
		conn = DBUtil.getConnection();
		String query = "INSERT INTO note_customer_mapping"
				+ "(note_seq, customer_seq, auth_write) " 
				+ "VALUES"
				+ "(%d, %d, 1)";
		query = String.format(query, noteSeq, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	
	//����
	public static String selectNoteCustomerMappings(int customerseq) {
		Connection conn = null;
		Statement stmt = null;
		String retVal="";
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "customerSeq", Constants.getDate(),  customerseq));
		
		conn = DBUtil.getConnection();
		
//		String query = "SELECT seq, folder_seq, title, reg_time, start_time, end_time, location, writer_customer_seq, contents"
//				+ " FROM note WHERE writer_customer_seq=%d and folder_seq=%d order by seq";
		
		String query = "SELECT note_seq, customer_seq, auth_write"
				+ " FROM note_customer_mapping WHERE customer_seq=%d";
		
		query = String.format(query, customerseq);

		Statement st = null;
		
		System.out.println("query Test : "+query);
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject mapping = new JsonObject();
				int noteSeq_ = rs.getInt("note_seq");
				mapping.addProperty("note_seq", noteSeq_);
				int customerSeq = rs.getInt("customer_seq");
				if (customerSeq > 0)
					mapping.addProperty("customer_seq", customerSeq);
				int authWrite = rs.getInt("auth_write");
				if (customerSeq > 0)
					mapping.addProperty("auth_write", authWrite);
				array.add(mapping);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}
	public static boolean updateNoteCustomerMappings(int noteSeq, int customerSeq, int authWrite) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteSeq", Constants.getDate(),  noteSeq));
		
		conn = DBUtil.getConnection();
		String query = "UPDATE note_customer_mapping SET auth_write=%d WHERE note_seq=%d AND customer_seq=%d";
		query = String.format(query, authWrite, noteSeq, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	public static boolean deleteNoteCustomerMappings(int noteSeq, int customerSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "noteSeq", Constants.getDate(),  noteSeq));
		
		conn = DBUtil.getConnection();
		String query = "DELETE FROM note_customer_mapping WHERE note_seq=%d AND customer_seq=%d";
		query = String.format(query, noteSeq, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	
	public static boolean insertReserveNoteCustomerMapping(int folderSeq, int customerSeq, int authWrite) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();
		String query = "INSERT INTO reserve_note_customer_mapping"
				+ "(folder_seq, customer_seq, auth_write) " 
				+ "VALUES"
				+ "(%d, %d, %d)";
		query = String.format(query, folderSeq, customerSeq, authWrite);
		Statement st = null;

		try {
			System.out.println("query: " + query);
			
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	public static String selectReserveNoteCustomerMappings(int folderSeq) {
		Connection conn = null;
		Statement stmt = null;
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();
		
		String query = "SELECT folder_seq, customer_seq, auth_write"
				+ " FROM reserve_note_customer_mapping WHERE folder_seq=%d";
		
		query = String.format(query, folderSeq);

		Statement st = null;
		
		System.out.println("query Test : "+query);
		
		Gson gson = new Gson();
		JsonArray array = new JsonArray();
		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			while(rs.next()) {
				JsonObject mapping = new JsonObject();
				int folderSeq_ = rs.getInt("folder_seq");
				mapping.addProperty("folder_seq", folderSeq_);
				int customerSeq = rs.getInt("customer_seq");
				if (customerSeq > 0)
					mapping.addProperty("customer_seq", customerSeq);
				int authWrite = rs.getInt("auth_write");
				if (customerSeq > 0)
					mapping.addProperty("auth_write", authWrite);
				array.add(mapping);
			}
			return gson.toJson(array);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return "";
	}
	public static boolean updateReserveNoteCustomerMappings(int folderSeq, int customerSeq, int authWrite) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();
		String query = "UPDATE reserve_note_customer_mapping SET auth_write=%d WHERE folder_seq=%d AND customer_seq=%d";
		query = String.format(query, authWrite, folderSeq, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	public static boolean deleteReserveNoteCustomerMappings(int folderSeq, int customerSeq) {
		Connection conn = null;
		Statement stmt = null;

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "folderSeq", Constants.getDate(),  folderSeq));
		
		conn = DBUtil.getConnection();
		String query = "DELETE FROM reserve_note_customer_mapping WHERE folder_seq=%d AND customer_seq=%d";
		query = String.format(query, folderSeq, customerSeq);
		Statement st = null;

		try {
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(conn);
		}
		return false;
	}
	
	public static int insertUser(UserVO vo) {

		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "insertUser", Constants.getDate(),  vo.getId()));


		Connection conn = null;
		Statement stmt = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();

			String sql = "INSERT INTO CUSTOMER VALUES (?, ?,?,?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getName());
			pstmt.setString(3, vo.getPassword());
			pstmt.setString(4, vo.getPnum());
			int retCnt = pstmt.executeUpdate();
			DBUtil.close(stmt);
			DBUtil.close(conn);
			System.out.println(String.format(Constants.LOG_END_FORMAT, "DbManager", "insertUser", Constants.getDate(), retCnt));
			return retCnt;

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return -1;
	}

	public static ArrayList<UserVO> selectAllUser() throws SQLException {
		System.out.println(String.format(Constants.LOG_START_FORMAT, "DbManager", "selectAllUser", Constants.getDate(), ""));
		ArrayList<UserVO> retList = new ArrayList();
		Connection conn = null;

		conn = DBUtil.getConnection();

		String query = "SELECT * FROM CUSTOMER";

		Statement st = conn.createStatement();

		ResultSet rs = st.executeQuery(query);
		while (rs.next()) {
			UserVO vo = new UserVO();
			vo.setId(rs.getString("id"));
			vo.setName(rs.getString("name"));
			vo.setPassword(rs.getString("password"));
			vo.setPnum(rs.getString("pnum"));
			retList.add(vo);
		}
		st.close();
		System.out.println(String.format(Constants.LOG_END_FORMAT, "DbManager", "selectAllUser", Constants.getDate(), retList.size()));
		return retList;
	}
}

package org.minutes.capstone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class SplashActivity extends Activity {

    private static final int MSG_START_MAIN_ACTIVITY = 1000;
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_START_MAIN_ACTIVITY:{
                    startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    finish();
                    break;
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        handler.sendEmptyMessageDelayed(MSG_START_MAIN_ACTIVITY, 2000);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeMessages(MSG_START_MAIN_ACTIVITY);
    }
}

package org.minutes.capstone;

public class Constants {
    public static String LOGIN_ID = "";
    public static int seq;
    public static int group_p;
    public static int child_p;
    public static int note_seq;
}

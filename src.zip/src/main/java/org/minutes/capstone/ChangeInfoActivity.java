package org.minutes.capstone;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.SharedPreferences;


import java.util.concurrent.ExecutionException;

public class ChangeInfoActivity extends AppCompatActivity {
    EditText idet;
    EditText nameet;
    EditText pwet;

    String id=Constants.LOGIN_ID;
    String pw;
    String name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_info);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("회원정보 수정");

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    public void onClickChangeName(View view) {
        Intent intent = new Intent(this, MeetingListActivity.class);
        startActivity(intent);

        nameet = (EditText) findViewById(R.id.nameet);
        name = nameet.getText().toString();


        DbAsyncTask task = new DbAsyncTask();
        boolean result = task.updateCustomer(Constants.LOGIN_ID, name);
        Log.e("test_code", "updateCustomer, result: " + result);
}


    public void onClickChangePassword(View view) {
        TextView pw12 = new TextView(this);
        TextView pw212 = new TextView(this);
        pw12 = (TextView)findViewById(R.id.pwet);
        pw212 = (TextView)findViewById(R.id.password2EditText);
        if(pw12.getText().toString().equals(pw212.getText().toString())) {
            Intent intent = new Intent(this, MeetingListActivity.class);
            startActivity(intent);

            pwet = (EditText) findViewById(R.id.pwet);
            pw = pwet.getText().toString();


            DbAsyncTask task = new DbAsyncTask();
            boolean result = task.updatePassword(Constants.LOGIN_ID, pw);
            Log.e("test_code", "updatePassword, result: " + result);

        }
        else {

        }
    }

    public void onClickDeleteAccount(View view){

        new AlertDialog.Builder(this)
                .setTitle("경고")
                .setMessage("탈퇴하시겠습니까? 모든 정보가 삭제됩니다.")
//                .setIcon(android.R.drawable.ic_menu_save)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // 확인시 처리 로직
                        Toast.makeText(ChangeInfoActivity.this, "탈퇴되었습니다.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ChangeInfoActivity.this, MainActivity.class);
                        startActivity(intent);
                         finish();

                      DbAsyncTask task = new DbAsyncTask();
                      boolean result = task.deleteCustomer(Constants.seq);
                      Log.e("test_code", "deleteCustomer, result: " + result);
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        // 취소시 처리 로직
                        Toast.makeText(ChangeInfoActivity.this, "취소하였습니다.", Toast.LENGTH_SHORT).show();
                    }})
                .show();
    }

}

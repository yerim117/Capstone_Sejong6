package org.minutes.capstone;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DbAsyncTask extends AsyncTask<String, Void, String> {
    private static final String URL = "http://172.16.18.156:8080/WebserverServlet/server.jsp";
    private static final String SUCCESS = "succ";

    public static class Customer {
        public int seq;
        public String id;
        public String name;
        public String pnum;

        public String toString() {
            return "seq: " + seq + ", id: " + id + ", name: " + name + ", pnum: " + pnum;
        }
    }
    public boolean login(String id, String password) {
        String args = String.format("type=login&id=%s&password=%s", id, password);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public boolean insertCustomer(String id, String name, String password, String pnum) {
        String args = String.format("type=insertCustomer&id=%s&name=%s&password=%s&pnum=%s",
                id, name, password, pnum);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    private List<Customer> selectCustomers(int customerSeq, String id, String likeName, String pnum) {
        String args = "type=selectCustomers";
        if (customerSeq > 0)
            args += "&seq=" + customerSeq;
        if (id != null)
            args += "&id=" + id;
        if (likeName != null)
            args += "&name=" + likeName;
        if (pnum != null)
            args += "&pnum=" + pnum;
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectCustomers, result: " + result);
            List<Customer> list = new ArrayList<Customer>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                Customer c = new Customer();
                if (obj.has("seq"))
                    c.seq = obj.getInt("seq");
                if (obj.has("id"))
                    c.id = obj.getString("id");
                if (obj.has("name"))
                    c.name = obj.getString("name");
                if (obj.has("pnum"))
                    c.pnum = obj.getString("pnum");
                list.add(c);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectCustomers", e);
        }


        return null;
    }
    public List<Customer> selectAllCustomers() {
        return selectCustomers(-1, null, null, null);
    }
    public List<Customer> selectCustomersByLikeName(String name) {
        return selectCustomers(-1, null, name, null);
    }

    public boolean updateCustomer(int customerSeq, String name) {
        String args = "type=updateCustomer";
        if (customerSeq > 0)
            args += "&seq=" + customerSeq;
        if (name != null)
            args += "&name='" + name + "'";
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
            Log.e("test_code", "selectCustomers", e);
        }
        return false;
    }

    public boolean updateCustomer(String id, String name) {
        String args = "type=updateCustomer";
        if (id != null)
            args += "&seq=" + id + "'";
        if (name != null)
            args += "&name='" + name + "'";
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
            Log.e("test_code", "selectCustomers", e);
        }
        return false;
    }

    public boolean updatePassword(String id, String newPassword) {
        String args = String.format("type=updatePassword&id=%s&newPassword=%s",
                id, newPassword);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public boolean deleteCustomer(int customerSeq) {
        String args = String.format("type=deleteCustomer&seq=%d", customerSeq);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public static class Folder {
        public static final int RESERVE_PERIOD_TYPE_MONTH = 0;
        public static final int RESERVE_PERIOD_TYPE_WEEK = 1;
        public static final int RESERVE_PERIOD_WEEK_1 = 1;
        public static final int RESERVE_PERIOD_WEEK_2 = 2;
        public static final int RESERVE_PERIOD_WEEK_3 = 3;
        public static final int RESERVE_PERIOD_WEEK_4 = 4;
        public static final int RESERVE_PERIOD_DAY_SUN = 0;
        public static final int RESERVE_PERIOD_DAY_MON = 1;
        public static final int RESERVE_PERIOD_DAY_TUE = 2;
        public static final int RESERVE_PERIOD_DAY_WED = 3;
        public static final int RESERVE_PERIOD_DAY_THU = 4;
        public static final int RESERVE_PERIOD_DAY_FRI = 5;
        public static final int RESERVE_PERIOD_DAY_SAT = 6;

        public int seq;
        public String title;
        public int parentFolderSeq;
        public String reserveTitle;
        public int reserveWriterCustomerSeq;
        public String reserveLocation;
        public int reservePeriodType;
        public int reservePeriodWeek;
        public int reservePeriodDay;
        public String reserveStartTime;
        public String reserveEndTime;

        public String toString() {
            return "seq: " + seq + ", titel: " + title + ", reserveTitle: " + reserveTitle + ", parentFolderSeq: " + parentFolderSeq
                    + ", reserveWriterCustomerSeq: " + reserveWriterCustomerSeq
                    + ", reserveLocation: " + reserveLocation + ", reservePeriodType: " + reservePeriodType
                    + ", reservePeriodWeek: " + reservePeriodWeek + ", reservePeriodDay: " + reservePeriodDay
                    + ", reserveStartTime: " + reserveStartTime + ", reserveEndTime: " + reserveEndTime;
        }
    }

    public boolean insertFolder(String title, int parentFolderSeq, String reserveTitle, int reserveWriterCustomerSeq,
                                String reserveLocation, int reservePeriodType, int reservePeriodWeek, int reservePeriodDay,
                                String reserveStartTime, String reserveEndTime) {
        String args = String.format("type=insertFolder&title=%s", title);
        if (parentFolderSeq > 0)
            args += "&parent_folder_seq=" + parentFolderSeq;
        if (reserveTitle != null)
            args += "&reserve_title=" + reserveTitle;
        if (reserveWriterCustomerSeq > 0)
            args += "&reserve_writer_customer_seq=" + reserveWriterCustomerSeq;
        if (reserveLocation != null)
            args += "&reserve_location=" + reserveLocation;
        if (reservePeriodType > -1)
            args += "&reserve_period_type=" + reservePeriodType;
        if (reservePeriodWeek > -1)
            args += "&reserve_period_week=" + reservePeriodWeek;
        if (reservePeriodDay > -1)
            args += "&reserve_period_day=" + reservePeriodDay;
        if (reserveStartTime != null)
            args += "&reserve_start_time=" + reserveStartTime;
        if (reserveEndTime != null)
            args += "&reserve_end_time=" + reserveEndTime;
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }
    public boolean insertTopFolder(String title) {
        return insertFolder(title, -1, null,-1,
                null, -1, -1, -1, null, null);
    }
    public boolean insertFolder(String title, int parentFolderSeq) {
        return insertFolder(title, parentFolderSeq, null,-1,
                null, -1, -1, -1, null, null);
    }
    public List<Folder> selectFolders(int parentFolderSeq) {
        String args = "type=selectFolders";
        if (parentFolderSeq > 0)
            args += "&parent_folder_seq=" + parentFolderSeq;
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectFolders, result: " + result);
            List<Folder> list = new ArrayList<Folder>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                Folder f = new Folder();
                if (obj.has("seq"))
                    f.seq = obj.getInt("seq");
                if (obj.has("title"))
                    f.title = obj.getString("title");
                if (obj.has("parent_folder_seq"))
                    f.parentFolderSeq = obj.getInt("parent_folder_seq");
                if (obj.has("reserve_title"))
                    f.reserveTitle = obj.getString("reserve_title");
                if (obj.has("reserve_writer_customer_seq"))
                    f.reserveWriterCustomerSeq = obj.getInt("reserve_writer_customer_seq");
                if (obj.has("reserve_location"))
                    f.reserveLocation = obj.getString("reserve_location");
                if (obj.has("reserve_period_type"))
                    f.reservePeriodType = obj.getInt("reserve_period_type");
                if (obj.has("reserve_period_week"))
                    f.reservePeriodWeek = obj.getInt("reserve_period_week");
                if (obj.has("reserve_period_day"))
                    f.reservePeriodDay = obj.getInt("reserve_period_day");
                if (obj.has("reserve_start_time"))
                    f.reserveStartTime = obj.getString("reserve_start_time");
                if (obj.has("reserve_end_time"))
                    f.reserveEndTime = obj.getString("reserve_end_time");
                list.add(f);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectFolders", e);
        }
        return null;
    }
    public List<Folder> selectAllFolders() {
        return selectFolders(-1);
    }
    public boolean updateFolder(int folderSeq, String title, String reserveTitle, int reserveWriterCustomerSeq,
                                String reserveLocation, int reservePeriodType, int reservePeriodWeek, int reservePeriodDay,
                                String reserveStartTime, String reserveEndTime) {
        String args = "type=updateFolder";
        if (folderSeq > 0)
            args += "&seq=" + folderSeq;
        if (title != null)
            args += "&title='" + title + "'";
        if (reserveTitle != null)
            args += "&reserve_title='" + reserveTitle + "'";
        if (reserveWriterCustomerSeq > 0)
            args += "&reserve_writer_customer_seq=" + reserveWriterCustomerSeq;
        if (reserveLocation != null)
            args += "&reserve_location='" + reserveLocation + "'";
        if (reservePeriodType > 0)
            args += "&reserve_period_type=" + reservePeriodType;
        if (reservePeriodWeek > 0)
            args += "&reserve_period_week=" + reservePeriodWeek;
        if (reservePeriodDay > 0)
            args += "&reserve_period_week=" + reservePeriodDay;
        if (reserveStartTime != null)
            args += "&reserve_start_time='" + reserveStartTime + "'";
        if (reserveEndTime != null)
            args += "&reserve_end_time='" + reserveEndTime + "'";
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
            Log.e("test_code", "updateFolder", e);
        }
        return false;
    }
    public boolean updateFolder(int folderSeq, String title) {
        return updateFolder(folderSeq, title, null, -1, null,
                -1, -1, -1, null, null);
    }
    public boolean deleteFolder(int folderSeq) {
        String args = String.format("type=deleteFolder&seq=%d", folderSeq);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public static class Note {
        public int seq;
        public int folderSeq;
        public String title;
        public String regTime;
        public String startTime;
        public String endTime;
        public String location;
        public int writerCustomerSeq;
        public String contents;

        public String toString() {
            return "seq: " + seq + ", folderSeq: " + folderSeq + ", title: " + title + ", regTime: " + regTime
                    + ", startTime: " + startTime + ", endTime: " + endTime + ", location: " + location
                    + ", writerCustomerSeq: " + writerCustomerSeq + ", contents: " + contents;
        }
    }

    public boolean insertNote(int folderSeq, String title, String regTime, String startTime, String endTime, String location,
                              int writerCustomerSeq, String contents) {
        String args = String.format("type=insertNote&folder_seq=%d&title=%s&reg_time=%s&start_time=%s&end_time=%s"
                        + "&location=%s&writer_customer_seq=%d&contents=%s",
                folderSeq, title, regTime, startTime, endTime, location, writerCustomerSeq, contents);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public List<Note> selectNotes(int writerCustomerSeq,int folderSeq) {
        String args = String.format("type=selectNotes&writer_customer_seq=%d&folder_seq=%d",writerCustomerSeq,folderSeq);
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectNotes, result: " + result);
            List<Note> list = new ArrayList<Note>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                Note n = new Note();
                if (obj.has("seq"))
                    n.seq = obj.getInt("seq");
                if (obj.has("folder_seq"))
                    n.folderSeq = obj.getInt("folder_seq");
                if (obj.has("title"))
                    n.title = obj.getString("title");
                if (obj.has("reg_time"))
                    n.regTime = obj.getString("reg_time");
                if (obj.has("start_time"))
                    n.startTime = obj.getString("start_time");
                if (obj.has("end_time"))
                    n.endTime = obj.getString("end_time");
                if (obj.has("location"))
                    n.location = obj.getString("location");
                if (obj.has("writer_customer_seq"))
                    n.writerCustomerSeq = obj.getInt("writer_customer_seq");
                if (obj.has("contents"))
                    n.contents = obj.getString("contents");
                list.add(n);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectNotes", e);
        }
        return null;
    }

    public List<Note> selectNotes2(int noteseq) {
        String args = String.format("type=selectNotes2&note_seq=%d",noteseq);
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectNotes, result: " + result);
            List<Note> list = new ArrayList<Note>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                Note n = new Note();
                if (obj.has("seq"))
                    n.seq = obj.getInt("seq");
                if (obj.has("folder_seq"))
                    n.folderSeq = obj.getInt("folder_seq");
                if (obj.has("title"))
                    n.title = obj.getString("title");
                if (obj.has("reg_time"))
                    n.regTime = obj.getString("reg_time");
                if (obj.has("start_time"))
                    n.startTime = obj.getString("start_time");
                if (obj.has("end_time"))
                    n.endTime = obj.getString("end_time");
                if (obj.has("location"))
                    n.location = obj.getString("location");
                if (obj.has("writer_customer_seq"))
                    n.writerCustomerSeq = obj.getInt("writer_customer_seq");
                if (obj.has("contents"))
                    n.contents = obj.getString("contents");
                list.add(n);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectNotes", e);
        }
        return null;
    }

    public boolean updateNote(int noteSeq, int folderSeq, String title, String regTime, String startTime,
                              String endTime, String location, int writerCustomerSeq, String contents) {
        String args = "type=updateNote";
        if (noteSeq > 0)
            args += "&seq=" + noteSeq;
        if (folderSeq > 0)
            args += "&folder_seq=" + folderSeq;
        if (title != null)
            args += "&title='" + title + "'";
        if (regTime != null)
            args += "&reg_time='" + regTime + "'";
        if (startTime != null)
            args += "&start_time='" + startTime + "'";
        if (endTime != null)
            args += "&end_time='" + endTime + "'";
        if (location != null)
            args += "&location='" + location + "'";
        if (writerCustomerSeq > 0)
            args += "&writer_customer_seq=" + writerCustomerSeq;
        if (contents != null)
            args += "&contents='" + contents + "'";
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
            Log.e("test_code", "updateNote", e);
        }
        return false;
    }
    public boolean deleteNote(int noteSeq) {
        String args = String.format("type=deleteNote&seq=%d", noteSeq);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public static class NoteCustomerMapping {
        public static final int AUTH_WRITHE_DENIED = 0;
        public static final int AUTH_WRITHE_GRANTED = 1;

        public int noteSeq;
        public int customerSeq;
        public int authWrite;

        public String toString() {
            return "noteSeq: " + noteSeq + ", customerSeq: " + customerSeq + ", authWrite: " + authWrite;
        }
    }

    public boolean insertNoteCustomerMapping(int noteSeq, int customerSeq, int authWrite) {
        String args = String.format("type=insertNoteCustomerMapping&note_seq=%d&customer_seq=%d&auth_write=%d",
                noteSeq, customerSeq, authWrite);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }
    public List<NoteCustomerMapping> selectNoteCustomerMappings(int customerSeq) {
        String args = String.format("type=selectNoteCustomerMappings&customer_seq=%d", customerSeq);
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectNoteCustomerMappings, result: " + result);
            List<NoteCustomerMapping> list = new ArrayList<NoteCustomerMapping>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                NoteCustomerMapping m = new NoteCustomerMapping();
                if (obj.has("note_seq"))
                    m.noteSeq = obj.getInt("note_seq");
                if (obj.has("customer_seq"))
                    m.customerSeq = obj.getInt("customer_seq");
                if (obj.has("auth_write"))
                    m.authWrite = obj.getInt("auth_write");
                list.add(m);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectNoteCustomerMappings", e);
        }
        return null;
    }
    public boolean updateNoteCustomerMappings(int noteSeq, int customerSeq, int authWrite) {
        String args = String.format("type=updateNoteCustomerMappings&note_seq=%d&customer_seq=%d&auth_write=%d",
                noteSeq, customerSeq, authWrite);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }
    public boolean deleteNoteCustomerMappings(int noteSeq, int customerSeq) {
        String args = String.format("type=deleteNoteCustomerMappings&note_seq=%d&customer_seq=%d",
                noteSeq, customerSeq);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    public static class ReserveNoteCustomerMapping {
        public static final int AUTH_WRITHE_DENIED = 0;
        public static final int AUTH_WRITHE_GRANTED = 1;

        public int folderSeq;
        public int customerSeq;
        public int authWrite;

        public String toString() {
            return "folderSeq: " + folderSeq + ", customerSeq: " + customerSeq + ", authWrite: " + authWrite;
        }
    }

    public boolean insertReserveNoteCustomerMapping(int folderSeq, int customerSeq, int authWrite) {
        String args = String.format("type=insertReserveNoteCustomerMapping&folder_seq=%d&customer_seq=%d&auth_write=%d",
                folderSeq, customerSeq, authWrite);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }
    public List<ReserveNoteCustomerMapping> selectReserveNoteCustomerMappings(int folderSeq) {
        String args = String.format("type=selectReserveNoteCustomerMappings&folder_seq=%d", folderSeq);
        try {
            String result = execute(args).get();
            Log.e("test_code", "selectReserveNoteCustomerMappings, result: " + result);
            List<ReserveNoteCustomerMapping> list = new ArrayList<ReserveNoteCustomerMapping>();
            JSONArray array = new JSONArray(result);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                ReserveNoteCustomerMapping m = new ReserveNoteCustomerMapping();
                if (obj.has("folder_seq"))
                    m.folderSeq = obj.getInt("folder_seq");
                if (obj.has("customer_seq"))
                    m.customerSeq = obj.getInt("customer_seq");
                if (obj.has("auth_write"))
                    m.authWrite = obj.getInt("auth_write");
                list.add(m);
            }
            return list;
        } catch (Exception e) {
            Log.e("test_code", "selectReserveNoteCustomerMappings", e);
        }
        return null;
    }
    public boolean updateReserveNoteCustomerMappings(int folderSeq, int customerSeq, int authWrite) {
        String args = String.format("type=updateReserveNoteCustomerMappings&folder_seq=%d&customer_seq=%d&auth_write=%d",
                folderSeq, customerSeq, authWrite);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }
    public boolean deleteReserveNoteCustomerMappings(int folderSeq, int customerSeq) {
        String args = String.format("type=deleteReserveNoteCustomerMappings&folder_seq=%d&customer_seq=%d",
                folderSeq, customerSeq);
        try {
            String result = execute(args).get();
            return SUCCESS.equals(result);
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    protected String doInBackground(String... strings) {
        // 접속할 서버 주소 (이클립스에서 android.jsp 실행시 웹브라우저 주소)
        URL url = null;
        String result = "";
        try {
            url = new URL(URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
            conn.setRequestMethod("POST");
            OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());

            String str;
            Log.e("test_code", "req, args: " + strings[0]);
            osw.write(strings[0]);
            osw.flush();

            //jsp와 통신 성공 시 수행
            if (conn.getResponseCode() == conn.HTTP_OK) {
                InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                BufferedReader reader = new BufferedReader(tmp);
                StringBuffer buffer = new StringBuffer();

                // jsp에서 보낸 값을 받는 부분
                while ((str = reader.readLine()) != null) {
                    buffer.append(str);
                }
                result = buffer.toString();

            } else {
                Log.e("withpd", "통신실패");
            }

        } catch (MalformedURLException e) {
            Log.e("test_code", "", e);
        } catch (UnsupportedEncodingException e) {
            Log.e("test_code", "", e);
        } catch (ProtocolException e) {
            Log.e("test_code", "", e);
        } catch (IOException e) {
            Log.e("test_code", "", e);
        }
        Log.e("test_code", "req, result: " + result);
        return result;
    }
}

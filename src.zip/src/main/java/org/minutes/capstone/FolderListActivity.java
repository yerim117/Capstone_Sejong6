package org.minutes.capstone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;

public class FolderListActivity extends AppCompatActivity {
    String value;
    final LinkedList<String> items = new LinkedList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(" 회 의 분 류");

        // 빈 데이터 리스트 생성.

        // Select 해와서 items 넣어준다


        // ArrayAdapter 생성. 아이템 View를 선택(sin
        // gle choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, items);

        // listview 생성 및 adapter 지정.
        final ListView listview = findViewById(R.id.listview1);
        listview.setAdapter(adapter);

        // 한번 눌렀을때 상세보기
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), ListActivity.class);
                intent.putExtra("key",position );
                startActivity(intent);
            }
        });

        //////////회의록 추가
        Button addButton = findViewById(R.id.add);
        addButton.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder ad = new AlertDialog.Builder(FolderListActivity.this);

                ad.setTitle("폴더 추가");       // 제목 설정

                // EditText 삽입하기
                final EditText et = new EditText(FolderListActivity.this);
                ad.setView(et);

                // 확인 버튼 설정
                ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {



                        // Text 값 받아서 로그 남기기
                        //
                        value = et.getText().toString();

//                        dialog.dismiss();     //닫기
                        // Event
                        items.add(value);
                        adapter.notifyDataSetChanged();
                        String id=Constants.LOGIN_ID;
                        String up_cat = "" + (adapter.getCount()-1);
                        String dn_cat="-1";
                        String title=value;


                        DbAsyncTask task = new DbAsyncTask();
                        try {
                            Log.e("withpd", "id : " + id);
                            Log.e("withpd", "up_cat : " + up_cat);
                            Log.e("withpd", "dn_cat : " + dn_cat);
                            Log.e("withpd", "title : " + title);
                            String res=task.execute("add_folder",id,up_cat, dn_cat,title).get();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }


                        Toast.makeText(FolderListActivity.this, "추가하였습니다.", Toast.LENGTH_SHORT).show();

                    }
                });
                // 취소 버튼 설정
                ad.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(FolderListActivity.this, "취소하였습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                // 창 띄우기
                ad.show();
                // listview 갱신
                adapter.notifyDataSetChanged();
            }
        });

        // 길게 누르면 삭제 dialog 뜸
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,final int position, long id) {
                final AlertDialog.Builder build=new AlertDialog.Builder(FolderListActivity.this);
                build.setTitle("삭제하시겠습니까 ?");

                build.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // 아이템 삭제

                        String id=Constants.LOGIN_ID;
                        String up_cat=""+position;
                        String title=items.get(position);

                        DbAsyncTask task = new DbAsyncTask();
                        try {
                            Log.e("withpd", "id : " + id);
                            Log.e("withpd", "up_cat : " + up_cat);
                            Log.e("withpd", "title : " + title);
                            task.execute("del_folder",id,up_cat,title).get();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        items.remove(position);
                        // listview 선택 초기화.
                        listview.clearChoices();
                        // listview 갱신.
                        adapter.notifyDataSetChanged();
//                                    }
                        Toast.makeText(FolderListActivity.this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    }

                });
                build.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                build.show();
                return true;
            }
        });
        getList(adapter);

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void getList(ArrayAdapter adapter) {
        DbAsyncTask task = new DbAsyncTask();
        try {
            String res=task.execute("sel_folder",Constants.LOGIN_ID).get();
            String[] titleList=res.split(",");
            for(int i=0; i<titleList.length; i++) {
                if(!titleList[i].equals("fail")){

                    items.add(titleList[i]);
                    adapter.notifyDataSetChanged();
                }
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_change_info, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_change_info:
                Intent intent = new Intent(this, ChangeInfoActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}


package org.minutes.capstone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.minutes.capstone.R;

import java.util.ArrayList;

public class AttendListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attend_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(" 참 석 자");

        // 빈 데이터 리스트 생성.
        final ArrayList<String> name = new ArrayList<String>();

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, name);

        // listview 생성 및 adapter 지정.
        final ListView listview = findViewById(R.id.listview2);
        listview.setAdapter(adapter);

        Intent intent = getIntent();
        int count=intent.getExtras().getInt("count");
        String index[]=intent.getStringArrayExtra("index");
        //ArrayList<String> index=intent.getExtras().getStringArrayList("index");
        //ArrayList<String> index=intent.getStringArrayListExtra("index");

//        for(int i=0;i<index.size();i++) {
//            name.add(index.get(i));
//        }

        for(int i=0;i<count;i++) {
            name.add(index[i]);
        }


    }
}
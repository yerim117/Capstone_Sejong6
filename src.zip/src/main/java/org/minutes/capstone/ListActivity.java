package org.minutes.capstone;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;

public class ListActivity extends AppCompatActivity {
    int up_position;

    final LinkedList<String> list = new LinkedList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        Intent intent = getIntent();
        up_position = (Integer)intent.getExtras().getInt("key");

//        up_position = intent.getIntExtra("key", "key");
        //up_position = intent.getIntExtra("key",position);
        System.out.println("test:up_position/"+up_position);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(" 회 의 록");

        // 빈 데이터 리스트 생성.
        //final ArrayList<String> list = new ArrayList<String>();

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);

        // listview 생성 및 adapter 지정.
        final ListView listview = findViewById(R.id.listview2);
        listview.setAdapter(adapter);

        // 한번 눌렀을때 상세보기
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), BFolderListActivity.class);
                intent.putExtra("upkey",up_position );
                intent.putExtra("dnkey",position );
                startActivity(intent);
                finish();

            }
        });

        // 길게 누르면 삭제 dialog 뜸
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                final AlertDialog.Builder build=new AlertDialog.Builder(ListActivity.this);
                build.setTitle("삭제하시겠습니까 ?");

                build.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
//                        int count, checked;
//                        count = adapter.getCount();
//                        if (count > 0) {
//                            // 현재 선택된 아이템의 position 획득.
//                            checked = listview.getCheckedItemPosition();
//                            if (checked > -1 && checked < count) {
                        // 아이템 삭제
                        String id=Constants.LOGIN_ID;
                        String up_cat="" + up_position;
                        String dn_cat="" + position;

                        DbAsyncTask task = new DbAsyncTask();
                        try {
                            Log.e("withpd", "id : " + id);
                            Log.e("withpd", "up_cat : " + up_cat);
                            Log.e("withpd", "dn_cat : " + dn_cat);
                            task.execute("del_list",id,up_cat,dn_cat).get();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        list.remove(position);

                        // listview 갱신.
                        adapter.notifyDataSetChanged();
                        Toast.makeText(ListActivity.this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                build.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                build.show();
                return true;
            }
        });
        //////////회의록 추가
//        Button addButton = findViewById(R.id.add2);
//        addButton.setOnClickListener(new Button.OnClickListener() {
//            public void onClick(View v) {
//                AlertDialog.Builder bu = new AlertDialog.Builder(ListActivity.this);
//
//                bu.setTitle("회의록 추가");       // 제목 설정
//
//                // EditText 삽입하기
//                final EditText et = new EditText(ListActivity.this);
////               TmpValClass.title = et.getText().toString();
//
//
//                bu.setView(et);
//
//                // 확인 버튼 설정
//                bu.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                        // Text 값 받아서 로그 남기기
//                        String value = et.getText().toString();
//
//                        String id=Constants.LOGIN_ID;
//                        String up_cat ="" + up_position;
//                        String dn_cat="" + (adapter.getCount());
//                        String title=value;
//
//
//                        DbAsyncTask task = new DbAsyncTask();
//                        try {
//                            Log.e("withpd", "id : " + id);
//                            Log.e("withpd", "up_cat : " + up_cat);
//                            Log.e("withpd", "dn_cat : " + dn_cat);
//                            Log.e("withpd", "title : " + title);
//                            task.execute("add_list",id,up_cat, dn_cat,title).get();
//                        } catch (ExecutionException e) {
//                            e.printStackTrace();
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
////                        dialog.dismiss();     //닫기
//                        // Event
//                        list.add(value);
//                        Toast.makeText(ListActivity.this, "추가하였습니다.", Toast.LENGTH_SHORT).show();
//
//                    }
//                });
//                // 취소 버튼 설정
//                bu.setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                        Toast.makeText(ListActivity.this, "취소하였습니다.", Toast.LENGTH_SHORT).show();
//                    }
//                });
//                // 창 띄우기
//                bu.show();
//                // listview 갱신
//                adapter.notifyDataSetChanged();
//            }
//        });
        getList(adapter);
    }


//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_meeting_list, menu);
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
////            case R.id.action_add_meeting:
////                Intent intent = new Intent(this, AddEditMeetingActivity.class);
////                startActivity(intent);
////                return true;
//
//            case R.id.action_change_info:
//                Intent intent = new Intent(this, ChangeInfoActivity.class);
//                startActivity(intent);
//                return true;
//
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }
    @Override
    public void onResume() {
        super.onResume();
    }

    public void getList(ArrayAdapter adapter) {
        DbAsyncTask task = new DbAsyncTask();

        String up_cat="" + up_position;
       // String dn_cat="" + position;


        try {
            String res=task.execute("sel_list",Constants.LOGIN_ID,up_cat).get();
            System.out.println("test:"+res);
            String[] titleList=res.split(",");
            for(int i=0; i<titleList.length; i++) {
                if(!titleList[i].equals("fail")){
                    list.add(titleList[i]);
                    adapter.notifyDataSetChanged();
                }
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_done, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_add_meeting_detail:
                Intent intent = new Intent(this, BAddEditActivity.class);
//                intent.putExtra("count",count);
//                intent.putExtra("index",index);
                startActivity(intent);
            case R.id.action_save_meeting_detail:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }



}
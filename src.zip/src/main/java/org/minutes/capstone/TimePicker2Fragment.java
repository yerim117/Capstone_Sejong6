package org.minutes.capstone;

import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.app.Dialog;
import android.text.format.DateFormat;
import android.widget.TimePicker;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.TextView;
import android.app.Dialog;
import java.util.Calendar;
import android.widget.TimePicker;

import java.util.Calendar;


public class TimePicker2Fragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_time_picker, container, false);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        //Use the current time as the default values for the time picker
        final Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);

        //Create and return a new instance of TimePickerDialog
        return new TimePickerDialog(getActivity(),this, hour, minute,
                DateFormat.is24HourFormat(getActivity()));
    }


    //onTimeSet() callback method
    public void onTimeSet(TimePicker view, int hourOfDay, int minute){
        //Do something with the user chosen time
        //Get reference of host activity (XML Layout File) TextView widget
        TextView endTime = (TextView) getActivity().findViewById(R.id.endTimeEditText1);

        if(hourOfDay<10 && minute<10) {
            endTime.setText("0" + String.valueOf(hourOfDay) +":0" + String.valueOf(minute) + ":00");
            TmpValClass.endTime = "0" + String.valueOf(hourOfDay) +":0" + String.valueOf(minute) + ":00";
//            etStartTime.setText("0" + hour + ":0" + minute + ":00");
        }
        else if(hourOfDay>=10 && minute<10) {
            endTime.setText(String.valueOf(hourOfDay) +":0" + String.valueOf(minute) + ":00");
            TmpValClass.endTime = String.valueOf(hourOfDay) +":0" + String.valueOf(minute) + ":00";
//            etStartTime.setText(hour + ":0" + minute + ":00");
        }
        else if(hourOfDay<10 && minute>=10) {
            endTime.setText("0" + String.valueOf(hourOfDay) +":" + String.valueOf(minute) + ":00");
            TmpValClass.endTime = "0" + String.valueOf(hourOfDay) +":" + String.valueOf(minute) + ":00";
//            etStartTime.setText("0" + hour + ":" + minute + ":00");
        }
        else {
            endTime.setText(String.valueOf(hourOfDay) +":" + String.valueOf(minute) + ":00");
            TmpValClass.endTime = String.valueOf(hourOfDay) +":" + String.valueOf(minute) + ":00";
//            etStartTime.setText(hour + ":" + minute + ":00");
        }




    }
}

package org.minutes.capstone;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    EditText idet;
    EditText pwet;

    String id;
    String pw;
    private static final int PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
//
//            if (checkSelfPermission(Manifest.permission.SEND_SMS)
//                    == PackageManager.PERMISSION_DENIED) {
//
//                Log.d("permission", "permission denied to SEND_SMS - requesting it");
//                String[] permissions = {Manifest.permission.SEND_SMS};
//
//                requestPermissions(permissions, PERMISSION_REQUEST_CODE);
//
//            }
//        }
//
//        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);
//        SmsManager smsManager = SmsManager.getDefault();
//        smsManager.sendTextMessage("01076769990", null, "받아라", null, null);
//
//        Toast.makeText(getApplicationContext(), "id : " + id + ", pw : " + pw, Toast.LENGTH_SHORT).show();
   }

    public void onClickLogin(View view) {


        idet = (EditText) findViewById(R.id.idet);
        pwet = (EditText) findViewById(R.id.pwet);

        id = idet.getText().toString();
        pw = pwet.getText().toString();

//        DbAsyncTask task = new DbAsyncTask();
//        try {
//            Log.e("withpd", "id : " + id);
//            Log.e("withpd", "pw : " + pw);
//            String result = task.execute("login", id, pw).get();
//   }
        DbAsyncTask task = new DbAsyncTask();
        boolean loginResult = task.login(id, pw);
        Log.e("withpd", "loginResult: " + loginResult);
        System.out.println("withpd,loginresult : " + loginResult);
        if (loginResult) {
            TmpValClass.addVar = 1;
            Intent intent = new Intent(this, BFolderListActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "정보가 맞지 않습니다", Toast.LENGTH_SHORT).show();
        }
        Constants.LOGIN_ID = id;
        System.out.println("LOGIN_ID: " + Constants.LOGIN_ID);

//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();

        int seq = 0;
        task = new DbAsyncTask();
        List<DbAsyncTask.Customer> customers = task.selectAllCustomers();
        Log.e("test_code", "selectAllCustomers");
        if (customers != null) {
            for (DbAsyncTask.Customer c : customers) {
                Log.e("test_code", "customer: " + c);
                if (c.id.equals(id)) {
                    Constants.seq = c.seq;
                    System.out.println("***seq : " + seq);
                }
            }

        }
    }

    public void onClickSignIn(View view) {
        Intent intent = new Intent(this, SignInActivity.class);
        startActivity(intent);
    }


}



package org.minutes.capstone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class BFolderListActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    //test
    private List<DbAsyncTask.Note> priv_notes = null;
    //////


    ExpandableListAdapter expandableListAdapter;
    ExpandableListView expandableListView;
    List<MenuModel> headerList = new ArrayList<>();
    HashMap<MenuModel, List<MenuModel>> childList = new HashMap<>();

    int group_p;
    int child_p;
    int note_p;

    // 빈 데이터 리스트 생성.
    final ArrayList<String> items = new ArrayList<String>();
    // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bfolder_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


//        // 빈 데이터 리스트 생성.
//        final ArrayList<String> items = new ArrayList<String>() ;

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, items);
        //adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, items) ;


        // listview 생성 및 adapter 지정.
        final ListView listview = (ListView) findViewById(R.id.listview1);
        listview.setAdapter(adapter);

        // 한번 눌렀을때 상세보기
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(BFolderListActivity.this, BAddEditActivity2.class);
                intent.putExtra("group_p", group_p);
                intent.putExtra("child_p", child_p);
                intent.putExtra("note_p",
                                priv_notes
                                        .get(position)
                                        .seq); // Constants.note_seq

                startActivity(intent);
            }
        });


        //        items.add("회의 1");
//        items.add("회의 2");
//        items.add("회의 3");
//System.out.println("TmpValClass.addVar"+TmpValClass.addVar);
        if (TmpValClass.addVar == 1) {
            DbAsyncTask task = new DbAsyncTask();
            List<DbAsyncTask.Note> notes = task.selectNotes(Constants.seq, 2);
            String title = "";
            Log.e("test_code", "selectNotes(2)");
            if (notes != null) {
                priv_notes = notes;
                for (DbAsyncTask.Note n : notes) {
                    Log.e("test_code", "note: " + n);
                    //if(n.seq.equals())
                    Constants.note_seq = n.seq;
                    title = n.title;
                    items.add(title);
                    adapter.notifyDataSetChanged();
                }
            }
//            System.out.println("확인1");
////            System.out.println("확인1.1 :"+Constants.seq);
////            task = new DbAsyncTask();
////            List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.seq);
////            if (list != null) {
////                for (DbAsyncTask.NoteCustomerMapping m : list) {
////                    Log.e("test_code", "NoteCustomerMapping: " + m);
////                    System.out.println("확인2");
////                    System.out.println("확인2.1 :"+m.customerSeq);
////                    if(m.customerSeq==Constants.seq){
////                        System.out.println("확인3");
////                        task = new DbAsyncTask();
////                        System.out.println("확인3.1 :"+m.noteSeq);
//                        notes = task.selectNotes2(m.noteSeq);
//                        title = "";
//                        if (notes != null) {
//                            System.out.println("확인4");
//                            priv_notes = notes;
//                            for (DbAsyncTask.Note n : notes) {
//                                System.out.println("확인5");
//                                Log.e("test_code", "note: " + n);
//                                Constants.note_seq = n.seq;
//                                title = n.title;
//                                items.add(title);
//                                adapter.notifyDataSetChanged();
//                            }
//                        }
//
//                    }
//
//                }
//            }
        }

        else if(TmpValClass.addVar == 2) {
            DbAsyncTask task = new DbAsyncTask();
            List<DbAsyncTask.Note> notes = task.selectNotes(Constants.seq, 3);
            String title = "";
            Log.e("test_code", "selectNotes(3)");
            if (notes != null) {
                priv_notes = notes;
                for (DbAsyncTask.Note n : notes) {
                    Log.e("test_code", "note: " + n);
                    //if(n.seq.equals())
                    Constants.note_seq = n.seq;
                    title = n.title;
                    items.add(title);
                    adapter.notifyDataSetChanged();
                }
            }

            task = new DbAsyncTask();
            List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.seq);
            if (list != null) {
                for (DbAsyncTask.NoteCustomerMapping m : list) {
                    Log.e("test_code", "NoteCustomerMapping: " + m);
                    if(m.customerSeq==Constants.seq){
                        task = new DbAsyncTask();
                        notes = task.selectNotes2(m.noteSeq);
                        title = "";
                        if (notes != null) {
                            priv_notes = notes;
                            for (DbAsyncTask.Note n : notes) {
                                Log.e("test_code", "note: " + n);
                                Constants.note_seq = n.seq;
                                title = n.title;
                                items.add(title);
                                adapter.notifyDataSetChanged();
                            }
                        }

                    }

                }
            }
        }
        else if (TmpValClass.addVar == 3) {
            DbAsyncTask task = new DbAsyncTask();
            List<DbAsyncTask.Note> notes = task.selectNotes(Constants.seq, 4);
            String title = "";
            Log.e("test_code", "selectNotes(4)");
            if (notes != null) {
                priv_notes = notes;
                for (DbAsyncTask.Note n : notes) {
                    Log.e("test_code", "note: " + n);
                    Constants.note_seq = n.seq;
                    title = n.title;
                    items.add(title);
                    adapter.notifyDataSetChanged();
                }
            }

            task = new DbAsyncTask();
            List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.seq);
            if (list != null) {
                for (DbAsyncTask.NoteCustomerMapping m : list) {
                    Log.e("test_code", "NoteCustomerMapping: " + m);
                    if(m.customerSeq==Constants.seq){
                        task = new DbAsyncTask();
                        notes = task.selectNotes2(m.noteSeq);
                        title = "";
                        if (notes != null) {
                            priv_notes = notes;
                            for (DbAsyncTask.Note n : notes) {
                                Log.e("test_code", "note: " + n);
                                Constants.note_seq = n.seq;
                                title = n.title;
                                items.add(title);
                                adapter.notifyDataSetChanged();
                            }
                        }

                    }

                }
            }
        }
        else if (TmpValClass.addVar == 4) {
            DbAsyncTask task = new DbAsyncTask();
            List<DbAsyncTask.Note> notes = task.selectNotes(Constants.seq, 6);
            String title = "";
            Log.e("test_code", "selectNotes(6)");
            if (notes != null) {
                priv_notes = notes;
                for (DbAsyncTask.Note n : notes) {
                    Log.e("test_code", "note: " + n);
                    Constants.note_seq = n.seq;
                    title = n.title;
                    items.add(title);
                    adapter.notifyDataSetChanged();
                }
            }
            task = new DbAsyncTask();
            List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.seq);
            if (list != null) {
                for (DbAsyncTask.NoteCustomerMapping m : list) {
                    Log.e("test_code", "NoteCustomerMapping: " + m);
                    if(m.customerSeq==Constants.seq){
                        task = new DbAsyncTask();
                        notes = task.selectNotes2(m.noteSeq);
                        title = "";
                        if (notes != null) {
                            priv_notes = notes;
                            for (DbAsyncTask.Note n : notes) {
                                Log.e("test_code", "note: " + n);
                                Constants.note_seq = n.seq;
                                title = n.title;
                                items.add(title);
                                adapter.notifyDataSetChanged();
                            }
                        }

                    }

                }
            }

        }
        else if (TmpValClass.addVar == 5) {
            DbAsyncTask task = new DbAsyncTask();
            List<DbAsyncTask.Note> notes = task.selectNotes(Constants.seq, 7);
            String title = "";
            Log.e("test_code", "selectNotes(7)");
            if (notes != null) {
                priv_notes = notes;
                for (DbAsyncTask.Note n : notes) {
                    Log.e("test_code", "note: " + n);
                    Constants.note_seq = n.seq;
                    title = n.title;
                    items.add(title);
                    adapter.notifyDataSetChanged();
                }
            }

            task = new DbAsyncTask();
            List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.seq);
            if (list != null) {
                for (DbAsyncTask.NoteCustomerMapping m : list) {
                    Log.e("test_code", "NoteCustomerMapping: " + m);
                    if(m.customerSeq==Constants.seq){
                        task = new DbAsyncTask();
                        notes = task.selectNotes2(m.noteSeq);
                        title = "";
                        if (notes != null) {
                            priv_notes = notes;
                            for (DbAsyncTask.Note n : notes) {
                                Log.e("test_code", "note: " + n);
                                Constants.note_seq = n.seq;
                                title = n.title;
                                items.add(title);
                                adapter.notifyDataSetChanged();
                            }
                        }

                    }

                }
            }
        }
        // 길게 누르면 삭제 dialog 뜸
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                final AlertDialog.Builder bu = new AlertDialog.Builder(BFolderListActivity.this);
                bu.setTitle("삭제하시겠습니까 ?");

                bu.setPositiveButton("네", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

//                        DbAsyncTask task = new DbAsyncTask();
//                        boolean result = task.deleteNote(Constants.note_seq);
//                        Log.e("test_code delete", "deleteNote(position), result: " + result);
                        // 아이템 삭제
                        items.remove(Constants.note_seq);
                        // listview 선택 초기화.
                        listview.clearChoices();
                        // listview 갱신.
                        adapter.notifyDataSetChanged();
                        Toast.makeText(BFolderListActivity.this, "삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    }

                });
                bu.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                bu.show();
                return true;
            }
        });


//        expandableListView = findViewById(R.id.expandableListView);
//        prepareMenuData();
//        populateExpandableList();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

//
//    public void onBackPressed(int groupPosition, int childPosition) {
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//
//        } else {
//
//
//            super.onBackPressed();
//
//
//        }
//
//
//        //System.out.println("555** : " + groupPosition + childPosition);
//    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();

        switch (item.getItemId()) {
            case R.id.action_add_meeting:
//                Intent intent = new Intent(this, BAddEditActivity.class);
//                startActivity(intent);
                Intent intent = new Intent(BFolderListActivity.this, BAddEditActivity.class);
                intent.putExtra("group_p", group_p);
                intent.putExtra("child_p", child_p);
                //intent.putExtra("note_p", priv_notes.get(position).seq); // Constants.note_seq
                startActivity(intent);
                return true;
            case R.id.logout:
//                intent = new Intent(this, MainActivity.class);
                intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                TmpValClass.addVar = 1;
                startActivity(intent);
                finish();
                return true;
            case R.id.action_alarm:
                intent = new Intent(this, BPopupAlarmActivity.class);
                // intent.putExtra("data", "Test Popup");
                startActivityForResult(intent, 1);
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id;
        id = item.getItemId();
        if (id == R.id.weekly_meeting) {
            Toast.makeText(this, "위클리", Toast.LENGTH_LONG).show();
            TmpValClass.addVar = 1;
            finish();
            startActivity(getIntent());
        } else if (id == R.id.monthly_meeting) {
            // 월간회의 목록
            Toast.makeText(this, "먼슬리", Toast.LENGTH_LONG).show();
            TmpValClass.addVar = 2;
            finish();
            startActivity(getIntent());
        } else if (id == R.id.biweekly_meeting) {
            // 격주회의 목록
            TmpValClass.addVar = 3;
            finish();
            startActivity(getIntent());
        } else if (id == R.id.irregular_meeting1) {
            // 비정기회의 기타1 목록
            TmpValClass.addVar = 4;
            finish();
            startActivity(getIntent());

        } else if (id == R.id.irregular_meeting1) {
            // 비정기회의 기타2 목록
            TmpValClass.addVar = 5;
            finish();
            startActivity(getIntent());
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

//    private void prepareMenuData() {
//
//        MenuModel menuModel;
////        MenuModel menuModel = new MenuModel("Android WebView Tutorial", true, false, ""); //Menu of Android Tutorial. No sub menus
////        headerList.add(menuModel);
////        if (!menuModel.hasChildren) {
////            childList.put(menuModel, null);
////        }
//        //////////////
//        String title1 = "";
//        String title2 = "";
//        String title3 = "";
//        String title4 = "";
//        String title5 = "";
//        String title6 = "";
//        String title7 = "";
//        DbAsyncTask task = new DbAsyncTask();
//        List<DbAsyncTask.Folder> folders = task.selectFolders(1);
//        Log.e("test_code", "selectFolders(1)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title1 = f.title;
//            }
//        }
//
//        menuModel = new MenuModel(title1, true, true, "");
//        //Menu of Java Tutorials
//        headerList.add(menuModel);
//        ////////////
//        List<MenuModel> childModelsList = new ArrayList<>();
//
//        task = new DbAsyncTask();
//        folders = task.selectFolders(2);
//        Log.e("test_code", "selectFolders(2)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title2 = f.title;
//            }
//        }
//        MenuModel childModel = new MenuModel(title2, false, false, "");
//        childModelsList.add(childModel);
//
//        task = new DbAsyncTask();
//        folders = task.selectFolders(3);
//        Log.e("test_code", "selectFolders(3)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title3 = f.title;
//            }
//        }
//
//        childModel = new MenuModel(title3, false, false, "");
//        childModelsList.add(childModel);
//
//        task = new DbAsyncTask();
//        folders = task.selectFolders(4);
//        Log.e("test_code", "selectFolders(4)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title4 = f.title;
//            }
//        }
//
//        childModel = new MenuModel(title4, false, false, "");
//        childModelsList.add(childModel);
//
//        if (menuModel.hasChildren) {
//            Log.d("API123", "here");
//            childList.put(menuModel, childModelsList);
//        }
//
//
//        ////////////////
//        childModelsList = new ArrayList<>();
//        task = new DbAsyncTask();
//        folders = task.selectFolders(5);
//        Log.e("test_code", "selectFolders(5)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title5 = f.title;
//            }
//        }
//        menuModel = new MenuModel(title5, true, true, ""); //Menu of Python Tutorials
//        headerList.add(menuModel);
//
//        task = new DbAsyncTask();
//        folders = task.selectFolders(6);
//        Log.e("test_code", "selectFolders(6)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title6 = f.title;
//            }
//        }
//        childModel = new MenuModel(title6, false, false, "");
//        childModelsList.add(childModel);
//
//        task = new DbAsyncTask();
//        folders = task.selectFolders(7);
//        Log.e("test_code", "selectFolders(7)");
//        if (folders != null) {
//            for (DbAsyncTask.Folder f : folders) {
//                Log.e("test_code", "folder: " + f);
//                title7 = f.title;
//            }
//        }
//        childModel = new MenuModel(title7, false, false, "");
//        childModelsList.add(childModel);
//
//        if (menuModel.hasChildren) {
//            childList.put(menuModel, childModelsList);
//        }
//    }
//
//    private void populateExpandableList() {
//
//        expandableListAdapter = new ExpandableListAdapter(this, headerList, childList);
//        expandableListView.setAdapter(expandableListAdapter);
//
//        expandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
//            @Override
//            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
//
//                if (headerList.get(groupPosition).isGroup) {
//                    if (!headerList.get(groupPosition).hasChildren) {
////                        WebView webView = findViewById(R.id.webView);
////                        webView.loadUrl(headerList.get(groupPosition).url);
//                        onBackPressed();
//                    }
//                }
//                Toast.makeText(getApplicationContext(), "onGroupClick1", Toast.LENGTH_SHORT).show();
//
//                return false;
//            }
//        });
//        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
//            @Override
//            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
//
//                if (childList.get(headerList.get(groupPosition)) != null) {
//                    MenuModel model = childList.get(headerList.get(groupPosition)).get(childPosition);
////                    if (model.url.length() > 0) {
////                        WebView webView = findViewById(R.id.webView);
////                        webView.loadUrl(model.url);
////                        onBackPressed();
////                    }
//                    group_p = groupPosition;
//                    child_p = childPosition;
//                   // Constants.group_p = groupPosition;
//                    //Constants.child_p = childPosition;
//
//
//                }
//
//                //Toast.makeText(getApplicationContext(),"onGroupClick2", Toast.LENGTH_SHORT).show();
//
//                return false;
//            }
//
//        });
//
//    }


}

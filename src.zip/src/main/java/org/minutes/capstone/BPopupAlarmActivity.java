package org.minutes.capstone;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;






public class BPopupAlarmActivity extends FragmentActivity{

    final Calendar calendarAlarm = Calendar.getInstance();

    TextView dateAlarmText;
    TextView timeAlarmText;
    long timeAlarm; // 시간 차이



    TimePickerDialog.OnTimeSetListener timepickerListener =
            new TimePickerDialog.OnTimeSetListener(){
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    calendarAlarm.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendarAlarm.set(Calendar.MINUTE, minute);

                    calendarAlarm.set(Calendar.SECOND,0);
                    calendarAlarm.set(Calendar.MILLISECOND,0);
                    timeAlarmText = new TextView(BPopupAlarmActivity.this);
                    timeAlarmText = (TextView)findViewById(R.id.timeAlarmTextView);
                    timeAlarmText.setText(hourOfDay+":"+minute+":00");
//                    updateDateAndTime();
                }
            };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //타이틀바 없애기
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_bpopup_alarm);









//        calendarAlarm.set(Calendar.HOUR_OF_DAY, 17);
//        calendarAlarm.set(Calendar.MINUTE, 49);
//        calendarAlarm.set(Calendar.SECOND, 50);
//        calendarAlarm.set(Calendar.MILLISECOND, 0);
//        calendarAlarm.set(Calendar.YEAR, 2019);
//        calendarAlarm.set(Calendar.MONTH, 5);
//        calendarAlarm.set(Calendar.DAY_OF_MONTH, 12);













    }



    public void onClickDateAlarm(View view) {
        this.DialogDatePicker();
    }



    private void DialogDatePicker(){
        Calendar c = Calendar.getInstance();
        int cyear = c.get(Calendar.YEAR);
        int cmonth = c.get(Calendar.MONTH);
        int cday = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            // onDateSet method
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String date_selected;
//                calendarAlarm.set(Calendar.YEAR, year);
//                calendarAlarm.set(Calendar.MONTH, monthOfYear);
//                calendarAlarm.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                date_selected = String.valueOf(year)+"-" + String.valueOf(monthOfYear+1)+"-" + String.valueOf(dayOfMonth);
                if((monthOfYear + 1)<10 && dayOfMonth<10) {
                    date_selected = String.valueOf(year)+"-0" + String.valueOf(monthOfYear+1)+"-0" + String.valueOf(dayOfMonth);
////            textViewD.setText(oCalendar.get(Calendar.YEAR)+"-0" + (oCalendar.get(Calendar.MONTH) + 1)+"-0" + oCalendar.get(Calendar.DAY_OF_MONTH));
                }
                else if((monthOfYear + 1)<10 && dayOfMonth>=10) {
                    date_selected = String.valueOf(year)+"-0" + String.valueOf(monthOfYear+1)+"-" + String.valueOf(dayOfMonth);
////            textViewD.setText(oCalendar.get(Calendar.YEAR)+"-0" + (oCalendar.get(Calendar.MONTH) + 1)+"-" + oCalendar.get(Calendar.DAY_OF_MONTH));
                }
                else if((monthOfYear + 1)>=10 && dayOfMonth<10) {
                    date_selected = String.valueOf(year)+"-" + String.valueOf(monthOfYear+1)+"-0" + String.valueOf(dayOfMonth);
////            textViewD.setText(oCalendar.get(Calendar.YEAR)+"-" + (oCalendar.get(Calendar.MONTH) + 1)+"-0" + oCalendar.get(Calendar.DAY_OF_MONTH));
                }
                else {
                    date_selected = String.valueOf(year)+"-" + String.valueOf(monthOfYear+1)+"-" + String.valueOf(dayOfMonth);
////            textViewD.setText(oCalendar.get(Calendar.YEAR)+"-" + (oCalendar.get(Calendar.MONTH) + 1)+"-" + oCalendar.get(Calendar.DAY_OF_MONTH));
                }

//                        Toast.makeText(AddEditMeetingActivity.this, "Selected Date is ="+date_selected, Toast.LENGTH_SHORT).show();
                dateAlarmText = new TextView(BPopupAlarmActivity.this);
                dateAlarmText = (TextView)findViewById(R.id.dateAlarmTextView);
                dateAlarmText.setText(date_selected);
//                TmpValClass.date = date_selected;
            }
        };
        DatePickerDialog alert = new DatePickerDialog(this,  mDateSetListener, cyear, cmonth, cday);
        calendarAlarm.set(Calendar.YEAR, cyear);
        calendarAlarm.set(Calendar.MONTH, cmonth);
        calendarAlarm.set(Calendar.DAY_OF_MONTH, cday);
        alert.show();
    }








    public void onClickTimeAlarm(View view) {
        new TimePickerDialog(this, timepickerListener,
                calendarAlarm.get(Calendar.HOUR_OF_DAY),
                //true, false 는 12시간,24시간 모드 설정
                calendarAlarm.get(Calendar.MINUTE), false).show();
    }





    //확인 버튼 클릭
    public void mOnClose(View v){
        //데이터 전달하기
        Intent intent = new Intent();
        intent.putExtra("result", "Close Popup");




        calendarAlarm.getTimeInMillis();


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date resultdate2 = new Date(System.currentTimeMillis());
        Date resultdate1 = new Date(calendarAlarm.getTimeInMillis());
        System.out.println("원하는거 " + sdf.format(resultdate1));
        System.out.println("오늘 " + sdf.format(resultdate2));


//        System.out.println("원하는거 " + t222);
//        System.out.println("오늘 " + t111);

//        System.currentTimeMillis ();

        timeAlarm = (calendarAlarm.getTimeInMillis() - System.currentTimeMillis());
        System.out.println("초 차이 " + timeAlarm / 1000);
        System.out.println("분 차이 " + timeAlarm / 1000 / 60);






        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //지연시키길 원하는 밀리초 뒤에 동작

                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.N_MR1) {
                    /**
                     * 누가버전 이하 노티처리
                     */
                    Toast.makeText(getApplicationContext(), "누가버전이하", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                    BitmapDrawable bitmapDrawable = (BitmapDrawable) getResources().getDrawable(R.mipmap.ic_launcher);
                    Bitmap bitmap = bitmapDrawable.getBitmap();

                    PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext()).
                            setLargeIcon(bitmap)
                            .setSmallIcon(R.mipmap.ic_launcher)
                            .setWhen(System.currentTimeMillis()).setShowWhen(true).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_MAX)
                            .setContentTitle("회의 참석")
                            .setDefaults(Notification.DEFAULT_VIBRATE)
                            .setFullScreenIntent(pendingIntent, true)
                            .setContentIntent(pendingIntent);

                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.notify(0, builder.build());

                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Toast.makeText(getApplicationContext(), "오레오이상", Toast.LENGTH_SHORT).show();
                    /**
                     * 오레오 이상 노티처리
                     */
//                    BitmapDrawable bitmapDrawable = (BitmapDrawable)getResources().getDrawable(R.mipmap.ic_launcher);
//                    Bitmap bitmap = bitmapDrawable.getBitmap();
                    /**
                     * 오레오 버전부터 노티를 처리하려면 채널이 존재해야합니다.
                     */

                    int importance = NotificationManager.IMPORTANCE_HIGH;
                    String Noti_Channel_ID = "Noti";
                    String Noti_Channel_Group_ID = "Noti_Group";

                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    NotificationChannel notificationChannel = new NotificationChannel(Noti_Channel_ID, Noti_Channel_Group_ID, importance);

//                    notificationManager.deleteNotificationChannel("testid"); 채널삭제

                    /**
                     * 채널이 있는지 체크해서 없을경우 만들고 있으면 채널을 재사용합니다.
                     */
                    if (notificationManager.getNotificationChannel(Noti_Channel_ID) != null) {
                        Toast.makeText(getApplicationContext(), "채널이 이미 존재합니다.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "채널이 없어서 만듭니다.", Toast.LENGTH_SHORT).show();
                        notificationManager.createNotificationChannel(notificationChannel);
                    }

                    notificationManager.createNotificationChannel(notificationChannel);
//                    Log.e("로그확인","===="+notificationManager.getNotificationChannel("testid1"));
//                    notificationManager.getNotificationChannel("testid");


                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), Noti_Channel_ID)
                            .setLargeIcon(null).setSmallIcon(R.mipmap.ic_launcher)
                            .setWhen(System.currentTimeMillis()).setShowWhen(true).
                                    setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_MAX)
                            .setContentTitle("회의 참석");
//                            .setContentIntent(pendingIntent);

//                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    notificationManager.notify(0, builder.build());

                }


            }
        }, timeAlarm);












        setResult(RESULT_OK, intent);

        finish();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }




}



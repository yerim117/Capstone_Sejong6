package org.minutes.capstone;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class BPopupAttendActivity extends Activity {

//    private List<String> list;          // 데이터를 넣은 리스트변수
//    private ListView listView;          // 검색을 보여줄 리스트변수
//    private EditText editSearch;        // 검색어를 입력할 Input 창
//    private SearchAdapter adapter;      // 리스트뷰에 연결할 아답터
//    private ArrayList<String> arraylist;

    ListView listview = null;
    ArrayAdapter adapter =  null;
    final LinkedList<String> items = new LinkedList<String>();
    int count=0,j=0;
    String[] index = new String[200];
    // final LinkedList<String> items2 = new LinkedList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_bpopup_attend);


        listview = findViewById(R.id.listview1);

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, items);

        // listview 생성 및 adapter 지정.
        listview.setAdapter(adapter);

//        //list1 ~ list 20
//        for(int i=0;i<10;i++){
//            items.add("사람 "+(i+1));
//        }

        DbAsyncTask task = new DbAsyncTask();
        String name;
        List<DbAsyncTask.Customer> customers = task.selectAllCustomers();
        Log.e("test_code", "selectAllCustomers");
        if (customers != null) {
            for (DbAsyncTask.Customer c : customers) {
                Log.e("test_code", "customer: " + c);
                name=c.name;
                items.add(name);
            }
        }

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                int check_position = listview.getCheckedItemPosition();   //리스트뷰의 포지션을 가져옴.
                Object vo = (Object)adapterView.getAdapter().getItem(i);  //리스트뷰의 포지션 내용을 가져옴.
                index[j] = ""+vo;
                //items2.add(""+vo);
                count++;
                j++;
//                Toast.makeText(BPopupAttendActivity.this, ""+ vo + " "+(i+1)+"count="+count+"index[j]"+index[j-1], Toast.LENGTH_SHORT).show();
                // Toast.makeText(MainActivity.this, items2.get(j), Toast.LENGTH_SHORT).show();
            }
        });


    }



    public void onResume() {
        super.onResume();
    }



    //확인 버튼 클릭
    public void mOnClose(View v){
        //데이터 전달하기
//        Intent intent = new Intent();
        Intent intent = new Intent(getApplicationContext(), BPopupAttend4Activity.class);
        intent.putExtra("count",count);
        intent.putExtra("index",index);

        intent.putExtra("result", "Close Popup");
        setResult(RESULT_OK, intent);

        startActivity(intent);
        finish();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }

}

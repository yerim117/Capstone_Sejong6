package org.minutes.capstone;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.minutes.capstone.Constants;
import org.minutes.capstone.DbAsyncTask;
import org.minutes.capstone.R;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;


public class AddAttendActivity extends AppCompatActivity {
    //ListView listview = null;
    //ArrayAdapter adapter =  null;
    final LinkedList<String> items = new LinkedList<String>();
    int count=0,j=0;
    String[] index = new String[200];


    //int up_position;
    //int dn_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_attend);

        //Intent intent = getIntent();
        //up_position = (Integer)intent.getExtras().getInt("upkey");
        //dn_position = (Integer)intent.getExtras().getInt("dnkey");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(" 참 석 자 추 가");

        // 빈 데이터 리스트 생성.
        // ArrayList<String> items = new ArrayList<String>();

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, items);

        // listview 생성 및 adapter 지정.
        final ListView listview = findViewById(R.id.listview1);
        listview.setAdapter(adapter);


        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                int check_position = listview.getCheckedItemPosition();   //리스트뷰의 포지션을 가져옴.
                Object vo = (Object)adapterView.getAdapter().getItem(i);  //리스트뷰의 포지션 내용을 가져옴.
                index[j] = ""+vo;
                count++;
                j++;
               // Toast.makeText(AddAttendActivity.this, ""+ vo + " "+(i+1)+"count="+count+"index[j]"+index[j-1], Toast.LENGTH_SHORT).show();
            }
        });


//        Button selectAllButton = (Button)findViewById(R.id.add) ;
//        selectAllButton.setOnClickListener(new Button.OnClickListener() {
//            public void onClick(View v) {
//                count = 0 ;
//                count = adapter.getCount() ;
//
//                for (int i=0; i<count; i++) {
//                    listview.setItemChecked(i, true) ;
//                }
//
//            }
//        }) ;

        getList(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_done, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_save_meeting_detail:
                Intent intent = new Intent(getApplicationContext(), AttendListActivity.class);
                intent.putExtra("count",count);
                intent.putExtra("index",index);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
    public void onResume() {
        super.onResume();
    }

    public void getList(ArrayAdapter adapter) {
        DbAsyncTask task = new DbAsyncTask();

//       String up_cat = "" +up_position;
//       String dn_cat = "" +dn_position;

        try {
            String res = task.execute("sel_attend",Constants.LOGIN_ID).get();
            String[] titleList = res.split(",");
            for (int i = 0; i < titleList.length; i++) {
                if (!titleList[i].equals("fail")) {
                    items.add(titleList[i]);
                    adapter.notifyDataSetChanged();
                    System.out.println("참석자 "+titleList[i]);
                }
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}
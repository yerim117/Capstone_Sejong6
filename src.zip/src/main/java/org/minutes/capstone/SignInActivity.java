package org.minutes.capstone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutionException;

public class SignInActivity extends AppCompatActivity {
    EditText idet;
    EditText nameet;
    EditText pwet;
    EditText pnet;

    String id;
    String pw;
    String name;
    String pnum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

      //  Toast.makeText(getApplicationContext(), "id : " + id + ", name : " + name +
                                                  //  ", pw : " + pw + ", pnum : " + pnum , Toast.LENGTH_SHORT).show();
    }

    public void onClickSignIn(View view) {
        TextView pw12 = new TextView(this);
        TextView pw212 = new TextView(this);
        pw12 = (TextView)findViewById(R.id.pwet);
        pw212 = (TextView)findViewById(R.id.signUserPW2EditText);
        if(pw12.getText().toString().equals(pw212.getText().toString())) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

            idet = (EditText) findViewById(R.id.idet);
            nameet = (EditText) findViewById(R.id.nameet);
            pwet = (EditText) findViewById(R.id.pwet);
            pnet = (EditText) findViewById(R.id.pnet);

            id = idet.getText().toString();
            name=nameet.getText().toString();
            pw = pwet.getText().toString();
            pnum = pnet.getText().toString();

//            DbAsyncTask task = new DbAsyncTask();
//        try {
//            Log.e("withpd", "id : " + id);
//            Log.e("withpd", "name : " + name);
//            Log.e("withpd", "pw : " + pw);
//            Log.e("withpd", "pnum : " + pnum);
//            task.execute("regist",id,name, pw,pnum).get();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
            DbAsyncTask task = new DbAsyncTask();
            boolean result = task.insertCustomer(id, name, pw, pnum);
            Log.e("test_code", "insertCustomer, result: " + result);
    }
        else {

        }

    }

    public void onClickGoLogin(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

}

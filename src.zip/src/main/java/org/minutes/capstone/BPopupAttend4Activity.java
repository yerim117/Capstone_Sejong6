package org.minutes.capstone;


import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import org.minutes.capstone.BAddEditActivity;
import org.minutes.capstone.R;

import java.util.ArrayList;
import java.util.List;

public class BPopupAttend4Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_bpopup_attend4);



        // 빈 데이터 리스트 생성.
        final ArrayList<String> name = new ArrayList<String>();

        // ArrayAdapter 생성. 아이템 View를 선택(single choice)가능하도록 만듦.
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, name);

        // listview 생성 및 adapter 지정.
        final ListView listview = findViewById(R.id.listview2);
        listview.setAdapter(adapter);

        Intent intent = getIntent();
        int count=intent.getExtras().getInt("count");
        String index[]=intent.getStringArrayExtra("index");
        //ArrayList<String> index=intent.getExtras().getStringArrayList("index");
        //ArrayList<String> index=intent.getStringArrayListExtra("index");

//        for(int i=0;i<index.size();i++) {
//            name.add(index.get(i));
//        }


//        // 빈 데이터 리스트 생성.
//        final ArrayList<String> name = new ArrayList<String>();

        for(int i=0;i<count;i++) {
            name.add(index[i]);
            DbAsyncTask task = new DbAsyncTask();

            List<DbAsyncTask.Customer> customers = task.selectCustomersByLikeName(index[i]);
            Log.e("test_code", "selectCustomersByLikeName(index[i])");
            System.out.println("이름 : "+index[i]);
            if (customers != null) {
                for (DbAsyncTask.Customer c : customers) {
                    if(c.name.equals(index[i])) {
                        task = new DbAsyncTask();
                        System.out.println("이름 :1 "+c.name);
                        System.out.println("이름 :2 "+c.seq);
                        boolean result = task.insertNoteCustomerMapping(Constants.note_seq, c.seq,1);
                        Log.e("test_code", "insertNoteCustomerMapping, result: " + result);
                        //Log.e("test_code", "customer: " + c);
                    }

                }
            }

        }

//        Button addButton = (Button)findViewById(R.id.ok) ;
//        addButton.setOnClickListener(new Button.OnClickListener() {
//            public void onClick(View v) {
//                Intent intent = new Intent(AttendListActivity.this, BAddEditActivity.class);
//                startActivity(intent);
//            }
//        }) ;


    }

    //확인 버튼 클릭
    public void mOnClose(View v){
        //데이터 전달하기
        Intent intent = new Intent();
        intent.putExtra("result", "Close Popup");
        setResult(RESULT_OK, intent);

//        DbAsyncTask task = new DbAsyncTask();
////        List<DbAsyncTask.NoteCustomerMapping> list = task.selectNoteCustomerMappings(Constants.note_seq);
////        Log.e("test_code", "selectNoteCustomerMappings(Constants.note_seq))");
////        if (list != null) {
////            for (DbAsyncTask.NoteCustomerMapping m : list) {
////                Log.e("test_code", "NoteCustomerMapping: " + m);
////            }
////        }


        finish();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }



}
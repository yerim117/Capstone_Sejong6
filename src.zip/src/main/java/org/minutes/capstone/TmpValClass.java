package org.minutes.capstone;

public class TmpValClass {
    public static String title;
    public static String date;
    public static String startTime;
    public static String endTime;
    public static String place;
    public static String writer;
    public static String manager;

    public static String contents;

    public static int addVar = 1;
}

